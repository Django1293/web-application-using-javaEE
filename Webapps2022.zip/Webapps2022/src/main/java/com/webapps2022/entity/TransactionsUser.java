/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;

/**
 *
 * @author HP
 */
@NamedQueries({
@NamedQuery(name = "getAllTransactions", query = "SELECT c FROM TransactionsUser c"),
@NamedQuery(name = "seeAllTransactions",query = "SELECT c FROM TransactionsUser c WHERE (c.sender = :username or c.receiver = :username)")
})
@Entity 

public class TransactionsUser implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long Id;

    @NotNull
    String sender;

    @NotNull
    String receiver;

    @NotNull
    Double amount;

    @Column
    LocalDateTime date_time;

    public TransactionsUser() {}

    public TransactionsUser(String sender, String receiver, Double amount, LocalDateTime date_time){
        this.sender = sender;
        this.receiver = receiver;
        this.amount = amount;
        this.date_time = date_time;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long Id) {
        this.Id = Id;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDateTime getDate_time() {
        return date_time;
    }

    public void setDate_time(LocalDateTime date_time) {
        this.date_time = date_time;
    }
    


}
