/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;

/**
 *
 * @author HP
 */
@NamedQuery(name = "findAllRequests", query = "SELECT c FROM RequestsUser c WHERE (c.request_to = :username and c.status = :status)")
@Entity
public class RequestsUser implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long ID;

    @NotNull
    String request_from;

    @NotNull
    String request_to;

    @NotNull
    Double amount;

    @Column
    String status;

    @Column
    LocalDateTime date_time;

    public RequestsUser(){}

    public RequestsUser(String request_from, String request_to, Double amount, String status, LocalDateTime date_time){

        this.request_from = request_from;
        this.request_to = request_to;
        this.amount = amount;
        this.status = status;
        this.date_time = date_time;

    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getRequest_from() {
        return request_from;
    }

    public void setRequest_from(String request_from) {
        this.request_from = request_from;
    }

    public String getRequest_to() {
        return request_to;
    }

    public void setRequest_to(String request_to) {
        this.request_to = request_to;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getDate_time() {
        return date_time;
    }

    public void setDate_time(LocalDateTime date_time) {
        this.date_time = date_time;
    }




    
}
