/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.restservice;

/**
 *
 * @author HP
 */
public class MOperations {

    
    String currency1;
    String currency2;

    Double amount_of_currency;

    Double result;

    public MOperations() {
    }

    public MOperations(String currency1, String currency2, Double amount_of_currency) {
        this.currency1 = currency1;
        this.currency2 = currency2;
        this.amount_of_currency = amount_of_currency;
    }

    public String getCurrency1() {
        return currency1;
    }

    public void setCurrency1(String currency1) {
        this.currency1 = currency1;
    }

    public String getCurrency2() {
        return currency2;
    }

    public void setCurrency2(String currency2) {
        this.currency2 = currency2;
    }

    public Double getAmount_of_currency() {
        return amount_of_currency;
    }

    public void setAmount_of_currency(Double amount_of_currency) {
        this.amount_of_currency = amount_of_currency;
    }

    public Double getResult() {
        return result;
    }

    public void setResult(Double result) {
        this.result = result;
    }
    
   
}
