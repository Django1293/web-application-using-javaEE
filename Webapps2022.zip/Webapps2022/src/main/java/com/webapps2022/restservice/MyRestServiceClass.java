/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.restservice;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author HP
 */
@Path("/MyRestServiceClass")
public class MyRestServiceClass {

    public MyRestServiceClass() {
    }

    @GET
    @Path("conversion/{currency1}/{currency2}/{amount_of_currency}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    public MOperations getResult(@PathParam("currency1") String c1, @PathParam("currency2") String c2, @PathParam("amount_of_currency") String amount) {

       Double amt;

        try {
            amt = Double.parseDouble(amount);
        } catch (NumberFormatException e) {
            return null;
        }

        Double result;

        if( c1.equalsIgnoreCase(c2)) { 
            result = amt;
        }
        else if(c1.equalsIgnoreCase("GBPounds")) 
            { 
            if(c2.equalsIgnoreCase("USDollars")) {
                result = amt *1.24;
            }
            else {
                result = amt * 1.18;
            }
        }
        else {
            if(c1.equalsIgnoreCase("USDollars")) {
                result = amt / 1.24;
            }
            else {
                result = amt / 1.17;
            }
        }


        MOperations m = new MOperations(c1, c2, amt);
        m.setResult(result);
        return m;
    }
}

