/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.restservice;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author HP
 */
public class MyRestServiceClient {

    public static MOperations runMyRestOperation(String c1, String c2, Double amt) {
        
        String webappURL = "http://localhost:10000/webapps2022/";
        String restPath = "/myrestapi/MyRestServiceClass/conversion/" + c1 + "/" + c2 + "/" + amt.toString();
        String restapiURI = webappURL + restPath;

        Client client = ClientBuilder.newClient();
        WebTarget myRestResource = client.target(restapiURI);
        Invocation.Builder builder = myRestResource.request(MediaType.APPLICATION_JSON);
        MOperations response = builder.get(MOperations.class);
        client.close();
        return response;
    }
}
