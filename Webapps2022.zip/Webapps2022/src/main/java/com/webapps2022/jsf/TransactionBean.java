/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;


import com.webapps2022.ejb.TransactionsEJB;
import com.webapps2022.ejb.UserService;
import com.webapps2022.entity.RequestsUser;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.TransactionsUser;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

@Named
@RequestScoped


public class TransactionBean implements Serializable {
     
    @EJB
    TransactionsEJB trans;
    
    @EJB
    UserService us;

    String receiver;
    Double amount;
    String username;

public TransactionBean() {}

@PostConstruct
public void init(){
this.username = FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
}

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void sendamount() {
       String s = trans.transactAmount(username, receiver, amount);
       FacesContext context = FacesContext.getCurrentInstance();


       if (s == "Success"){
        


        context.addMessage(null, new FacesMessage("Last Transaction was successfull"));
       }
       else if (s == "Insufficient"){
        context.addMessage(null, new FacesMessage("INSUFFICIENT BALANCE!, Transaction Unsuccessful"));
       
       }   
       else if (s == "NoUser"){
        context.addMessage(null, new FacesMessage("USER NOT FOUND!, Transaction Unsuccessful"));
       }   
    
    }
    public void requestamount() {
        trans.requestAmount(username, receiver, amount);
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage("Request made"));
      

    }
    
    public List<RequestsUser> getRequestsList(){
    String username_ = this.username;
    String status_ = "pending";
    List<RequestsUser> reqlist = trans.RequestsList(username_,status_);
    
    return reqlist;
    }
    public List<TransactionsUser> getTransactionsList(){
    String username_ = this.username;
    List<TransactionsUser> transactlist = trans.TransactionsList(username_);
    
    return transactlist;
    }

    public void processRequest(String username,String receiver,Double amount, Long ID) {
        String s = trans.transactAmountRequest(username, receiver, amount, ID);
        FacesContext context = FacesContext.getCurrentInstance();
        
        if(s == "Success"){
        context.addMessage(null, new FacesMessage("Request Approved"));
        }
        else if(s == "Insufficient"){
        context.addMessage(null, new FacesMessage("INSUFFICIENT BALANCE"));

        }
        else if (s == "UNK"){
        context.addMessage(null, new FacesMessage("Could not process request"));
        }

    }
    public void rejectRequest(Long ID) {

        trans.transactReject(ID);
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage("Request Rejected"));
    



    }
    public Double getBalance(){
      String username_ = this.username;
      Double b = us.getBalance(username_);
      
      return b;
    }
    public List<SystemUser> getUsersList(){
        List<SystemUser> reqlist = us.getUsersList();
        return reqlist;

    }
    public List<TransactionsUser> getAllTransactions(){
    
    List<TransactionsUser> transactlist = trans.getAllTransactions();
    return transactlist;
    }
}

