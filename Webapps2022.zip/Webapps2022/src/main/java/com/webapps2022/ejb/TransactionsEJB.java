/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;


import com.webapps2022.entity.RequestsUser;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.TransactionsUser;
import java.time.LocalDateTime;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
@TransactionAttribute(REQUIRED)
public class TransactionsEJB {
    @PersistenceContext
    EntityManager em;

    public TransactionsEJB(){}


    public String transactAmount(String username, String receiver, Double amount) {
        
            
            SystemUser sender_ = em.find(SystemUser.class,username);
            SystemUser receiver_ = em.find(SystemUser.class,receiver);
            TransactionsUser transact; 

            if (sender_!=null & receiver_!=null){
            
                if (sender_.getBalance()> amount & amount >= 0){
                sender_.setBalance(sender_.getBalance()-amount);
                receiver_.setBalance(receiver_.getBalance()+amount);

                transact = new TransactionsUser(username,receiver, amount, LocalDateTime.now());
                
                em.persist(sender_);
                em.persist(receiver_);
                em.persist(transact);
                em.flush();
                return "Success";
                }
                else{
                return "Insufficient";
                }
            }
            else{
            return "NoUser";
            
            }
    

    }
    public void requestAmount(String username, String receiver, Double amount)  {
            SystemUser sender_ = em.find(SystemUser.class,username);
            SystemUser receiver_ = em.find(SystemUser.class,receiver);
            RequestsUser requests_;
            String status = "pending";

            if (sender_!=null & receiver_!=null){

            requests_ = new RequestsUser(username, receiver, amount, status, LocalDateTime.now());
            
            em.persist(requests_);
            em.flush();

            }


    }

    public synchronized List<RequestsUser> RequestsList(String username, String status) {
         List<RequestsUser> requests = em.createNamedQuery("findAllRequests").setParameter("username",username).setParameter("status",status).getResultList();
         
         return requests;
    }

    public synchronized List<TransactionsUser> TransactionsList(String username){
       List<TransactionsUser> transact = em.createNamedQuery("seeAllTransactions").setParameter("username",username).getResultList();
       return transact;


    }
    public String transactAmountRequest(String username, String receiver, Double amount, Long ID) {
        
            
            SystemUser sender_ = em.find(SystemUser.class,username);
            SystemUser receiver_ = em.find(SystemUser.class,receiver);
            TransactionsUser transact; 
            RequestsUser request = em.find(RequestsUser.class,ID);

            if (sender_!=null & receiver_!=null){
            
                if (sender_.getBalance()> amount & amount>= 0 ){
                sender_.setBalance(sender_.getBalance()-amount);
                receiver_.setBalance(receiver_.getBalance()+amount);

                transact = new TransactionsUser(username,receiver, amount, LocalDateTime.now());
                request.setStatus("Approved");
                
                em.persist(sender_);
                em.persist(receiver_);
                em.persist(transact);
                em.persist(request);
                em.flush();
                return "Success";
                }
                else {
                return "Insufficient";
                }
             
            }
            else {
            return "UNK";
            }
    }

    public void transactReject(Long ID){

        RequestsUser request = em.find(RequestsUser.class,ID);
        request.setStatus("Rejected");
        em.persist(request);
        em.flush();
    


    }
    public synchronized List<TransactionsUser> getAllTransactions(){
       List<TransactionsUser> transact = em.createNamedQuery("getAllTransactions").getResultList();
       return transact;
    }

}
            
   

          
            

            
            
        
            
    





