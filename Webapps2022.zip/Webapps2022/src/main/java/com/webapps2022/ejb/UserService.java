package com.webapps2022.ejb;

import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.SystemUserGroup;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.webapps2022.restservice.MyRestServiceClient;
import com.webapps2022.restservice.JAXRSConfiguration;
import com.webapps2022.restservice.MyRestServiceApplication;
import com.webapps2022.restservice.MyRestServiceClass;
import com.webapps2022.restservice.MOperations;
import javax.json.JsonArray;

/**
 *
 * @author parisis
 */
@Stateless
public class UserService {

    @PersistenceContext
    EntityManager em;
    Double balance = 1000.00;
    

    public UserService() {
    }

    public void registerUser(String username, String userpassword, String name, String surname, String currency) {
        try {
            SystemUser sys_user;
            SystemUserGroup sys_user_group;

            
            

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String passwd = userpassword;
            md.update(passwd.getBytes("UTF-8"));
            byte[] digest = md.digest();
            BigInteger bigInt = new BigInteger(1, digest);
            String paswdToStoreInDB = bigInt.toString(16);

            // apart from the default constructor which is required by JPA
            // you need to also implement a constructor that will make the following code succeed
            sys_user = new SystemUser(username, paswdToStoreInDB, name, surname,balance,currency);
            sys_user_group = new SystemUserGroup(username, "users");

            em.persist(sys_user);
            em.persist(sys_user_group);
            
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void registerAdmin(String username, String userpassword, String name, String surname) {
        try {
            SystemUser sys_user;
            SystemUserGroup sys_user_group;
            Double balance_ = 1000.00;

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String passwd = userpassword;
            md.update(passwd.getBytes("UTF-8"));
            byte[] digest = md.digest();
            BigInteger bigInt = new BigInteger(1, digest);
            String paswdToStoreInDB = bigInt.toString(16);
            String currency_ = "GBPounds";

            // apart from the default constructor which is required by JPA
            // you need to also implement a constructor that will make the following code succeed
            sys_user = new SystemUser(username, paswdToStoreInDB, name, surname,balance_,currency_);
            sys_user_group = new SystemUserGroup(username, "admins");

            em.persist(sys_user);
            em.persist(sys_user_group);
            
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public Double getBalance(String username){
          SystemUser sys_user = em.find(SystemUser.class, username);
          Double balance_ = sys_user.getBalance();
          
          return balance_;
    }  

    public List<SystemUser> getUsersList(){
    
    List<SystemUser> list_ = em.createNamedQuery("findAllUsersDetails").getResultList();
    return list_;
    }

    public Double runMyRestService(String Currency1, String Currency2, Double amountofcurrency1){
    

    MOperations obj = MyRestServiceClient.runMyRestOperation( Currency1, Currency2,amountofcurrency1 );
    Double result = obj.getResult();
    return result;

    }
}
