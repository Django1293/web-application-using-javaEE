/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.SystemUserGroup;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.ejb.Startup;

/**
 *
 * @author HP
 */
@Startup
@Singleton
public class StartupService {
    @PersistenceContext
    EntityManager em;

public StartupService(){
}

String username = "admin1";
String userpassword = "admin1";
String name = "admin";
String surname = "1";
Double balance = 1000.00;

@PostConstruct
public void init(){

registerDefaultAdmin(username,userpassword,name,surname, balance);

}

public void registerDefaultAdmin(String username, String userpassword, String name, String surname, Double balance) {
        
        SystemUser sys_admin = em.find(SystemUser.class,username);
        if (sys_admin == null){
        try {
            
            SystemUser sys_user;
            SystemUserGroup sys_user_group;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String passwd = userpassword;
            md.update(passwd.getBytes("UTF-8"));
            byte[] digest = md.digest();
            BigInteger bigInt = new BigInteger(1, digest);
            String paswdToStoreInDB = bigInt.toString(16);
            String currency_ = "GB Pounds";

            // apart from the default constructor which is required by JPA
            // you need to also implement a constructor that will make the following code succeed
            sys_user = new SystemUser(username, paswdToStoreInDB, name, surname,balance,currency_);
            sys_user_group = new SystemUserGroup(username, "admins");

            em.persist(sys_user);
            em.persist(sys_user_group);
            
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }















}
